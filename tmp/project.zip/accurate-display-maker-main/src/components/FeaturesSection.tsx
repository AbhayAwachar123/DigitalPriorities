import { motion } from "framer-motion";
import pieChart from "@/assets/pie-chart.png";
import { FileText, Figma } from "lucide-react";

const FeaturesSection = () => {
  return (
    <section className="py-20 px-4">
      <div className="max-w-[1200px] mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Proven Results Tile */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-secondary border border-border rounded-[20px] p-8 md:p-10 overflow-hidden relative"
            style={{ boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.07)" }}
          >
            <div className="mb-6">
              <h4 className="text-foreground text-xl font-medium mb-2">Proven results</h4>
              <p className="text-muted-foreground text-base leading-[1.8]">
                Our designs don't just look good—they drive an average +42% increase in conversions.
              </p>
            </div>
            {/* Bar Graph + Pie Chart */}
            <div className="flex items-end gap-4 mt-8">
              <div className="bg-background rounded-[10px] p-5 flex-1" style={{ boxShadow: "30px 40px 30px 0px rgba(0,0,0,0.8)" }}>
                <p className="text-foreground text-2xl font-bold mb-4">+42%</p>
                <div className="flex items-end gap-2 h-[80px]">
                  {[40, 55, 70, 85, 100].map((h, i) => (
                    <div
                      key={i}
                      className="flex-1 rounded-t-[5px]"
                      style={{
                        height: `${h}%`,
                        backgroundColor: "hsl(var(--primary))",
                        maskImage: "linear-gradient(0deg, rgba(0,0,0,0) 0%, rgba(0,0,0,1) 100%)",
                        WebkitMaskImage: "linear-gradient(0deg, rgba(0,0,0,0) 0%, rgba(0,0,0,1) 100%)",
                      }}
                    />
                  ))}
                </div>
              </div>
              <div className="w-16 h-16 flex-shrink-0">
                <img src={pieChart} alt="Pie Chart" className="w-full h-full object-cover" />
              </div>
            </div>
          </motion.div>

          {/* Rapid Turnaround Tile */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="bg-secondary border border-border rounded-[20px] p-8 md:p-10 overflow-hidden relative"
            style={{ boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.07)" }}
          >
            <div className="mb-6">
              <h4 className="text-foreground text-xl font-medium mb-2">Rapid turnaround</h4>
              <p className="text-muted-foreground text-base leading-[1.8]">
                Most design requests are completed within 48 hours or less.
              </p>
            </div>
            {/* Notification Cards */}
            <div className="space-y-3 mt-8">
              <div className="bg-background rounded-[10px] p-4 flex items-center gap-3">
                <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center flex-shrink-0">
                  <Figma className="w-5 h-5 text-foreground" />
                </div>
                <div>
                  <p className="text-foreground text-sm font-medium">New Framer project</p>
                  <p className="text-muted-foreground text-xs">Today, 11:08AM</p>
                </div>
              </div>
              <div
                className="bg-background rounded-[10px] p-4 flex items-center gap-3"
                style={{ boxShadow: "0px 50px 20px -30px rgba(0,0,0,0.5)" }}
              >
                <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center flex-shrink-0">
                  <FileText className="w-5 h-5 text-foreground" />
                </div>
                <div>
                  <p className="text-foreground text-sm font-medium">New Figma file</p>
                  <p className="text-muted-foreground text-xs">Today, 11:02AM</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
