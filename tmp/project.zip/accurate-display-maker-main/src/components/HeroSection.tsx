import { motion } from "framer-motion";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-4 overflow-hidden">
      {/* Grid background */}
      <div
        className="absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage: `linear-gradient(hsl(var(--border)) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--border)) 1px, transparent 1px)`,
          backgroundSize: "80px 80px",
        }}
      />

      {/* Radial gradient overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_transparent_0%,_hsl(var(--background))_70%)]" />

      <div className="relative z-10 text-center max-w-4xl mx-auto">
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, type: "spring", bounce: 0.2 }}
          className="inline-flex items-center gap-2 bg-badge-bg border border-badge-border rounded-full px-5 py-2 mb-8"
          style={{ boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.25)" }}
        >
          <span className="w-2.5 h-2.5 bg-green-dot rounded-full animate-pulse" />
          <span className="text-muted-foreground text-sm">3 spots left for Q2</span>
        </motion.div>

        {/* Heading */}
        <motion.h1
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1, type: "spring", bounce: 0.2 }}
          className="text-4xl sm:text-5xl md:text-7xl font-normal tracking-[-0.04em] leading-[1.2] mb-6"
          style={{
            maskImage: "linear-gradient(180deg, rgba(0,0,0,1) 0%, rgba(0,0,0,0.5) 100%)",
            WebkitMaskImage: "linear-gradient(180deg, rgba(0,0,0,1) 0%, rgba(0,0,0,0.5) 100%)",
          }}
        >
          <span className="text-foreground">Websites that convert</span>
          <br />
          <span className="text-foreground">visitors into buyers</span>
        </motion.h1>

        {/* Subtext */}
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2, type: "spring", bounce: 0.2 }}
          className="text-muted-foreground text-base md:text-[19px] max-w-2xl mx-auto mb-10 leading-[1.7]"
        >
          Get a high-performing website designed to turn clicks into customers,
          <br className="hidden md:block" />
          all with a simple, stress-free subscription—no contracts, no hassle.
        </motion.p>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3, type: "spring", bounce: 0.2 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-6"
        >
          <a
            href="#"
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 rounded-[10px] text-base font-medium transition-colors relative overflow-hidden group"
            style={{ boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.25)" }}
          >
            <span className="absolute inset-0 bg-foreground opacity-0 group-hover:opacity-10 blur-[40px] transition-opacity" />
            <span className="relative">Get template for free</span>
          </a>

          <div className="flex flex-col items-start">
            <div className="flex gap-0.5">
              {[...Array(5)].map((_, i) => (
                <svg key={i} className="w-4 h-4 text-star" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              ))}
            </div>
            <span className="text-muted-foreground text-sm mt-1">300+ founders trust us</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
