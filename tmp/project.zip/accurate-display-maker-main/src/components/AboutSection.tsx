import { motion } from "framer-motion";
import { useRef } from "react";
import agencyWorkspace from "@/assets/agency-workspace.jpg";
import { Palette, Frame, Globe, Pencil, Layout } from "lucide-react";

const services = [
  { icon: Palette, label: "Graphic Design" },
  { icon: Frame, label: "Framer Design" },
  { icon: Globe, label: "Web Design" },
  { icon: Pencil, label: "UI/UX Design" },
  { icon: Layout, label: "Brand Identity" },
];

const stats = [
  { value: "30%", label: "More conversions" },
  { value: "200+", label: "Projects completed" },
  { value: "48h", label: "Average delivery" },
];

const AboutSection = () => {
  const scrollRef = useRef<HTMLDivElement>(null);

  return (
    <section className="py-20 px-4">
      <div className="max-w-[1200px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Left: Services scroll + Image */}
          <div className="space-y-6">
            {/* Scrolling service tags */}
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="overflow-hidden"
              style={{
                maskImage: "linear-gradient(to right, rgba(0,0,0,0) 0%, rgba(0,0,0,1) 10%, rgba(0,0,0,1) 90%, rgba(0,0,0,0) 100%)",
                WebkitMaskImage: "linear-gradient(to right, rgba(0,0,0,0) 0%, rgba(0,0,0,1) 10%, rgba(0,0,0,1) 90%, rgba(0,0,0,0) 100%)",
              }}
            >
              <div className="flex gap-3 animate-[scroll_20s_linear_infinite]" ref={scrollRef}>
                {[...services, ...services, ...services].map((s, i) => (
                  <a
                    key={i}
                    href="#"
                    className="flex items-center gap-2 bg-secondary border border-border rounded-[15px] px-5 py-3 flex-shrink-0 hover:bg-accent transition-colors"
                    style={{ boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.25)" }}
                  >
                    <s.icon className="w-5 h-5 text-foreground" />
                    <span className="text-foreground text-sm font-medium whitespace-nowrap">{s.label}</span>
                  </a>
                ))}
              </div>
            </motion.div>

            {/* Workspace image */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="rounded-[20px] overflow-hidden aspect-[4/5]"
            >
              <img src={agencyWorkspace} alt="Agency Workspace" className="w-full h-full object-cover" />
            </motion.div>
          </div>

          {/* Right: Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-col gap-6"
          >
            {stats.map((stat, i) => (
              <div key={i} className="flex items-center gap-6">
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center border border-[rgba(255,255,255,0.15)] flex-shrink-0"
                  style={{
                    background: "linear-gradient(180deg, hsl(var(--secondary)) 0%, hsl(var(--background)) 100%)",
                    boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.25)",
                  }}
                >
                  <span className="text-foreground text-xs font-medium">✦</span>
                </div>
                <div>
                  <h3 className="text-foreground text-3xl md:text-4xl font-normal tracking-[-0.04em]">{stat.value}</h3>
                  <p className="text-muted-foreground text-base">{stat.label}</p>
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
