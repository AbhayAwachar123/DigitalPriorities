import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown } from "lucide-react";

const faqs = [
  {
    question: "What's included in the subscription?",
    answer: "Our subscription includes unlimited design requests, revisions, and a dedicated designer. You get access to all design services including web design, graphic design, and UI/UX design.",
  },
  {
    question: "How fast will I receive my designs?",
    answer: "Most design requests are completed within 48 hours. More complex projects may take longer, but we always keep you updated on the timeline.",
  },
  {
    question: "How involved will I be in the process?",
    answer: "As involved as you want to be! We provide regular updates and revisions until you're 100% satisfied. You can provide detailed briefs or let us take creative direction.",
  },
  {
    question: "Can you work with my existing brand?",
    answer: "Absolutely! We're experienced in working within established brand guidelines. Just share your brand assets and we'll ensure all designs are consistent with your brand identity.",
  },
];

const FAQSection = () => {
  const [open, setOpen] = useState<number | null>(null);

  return (
    <section className="py-20 px-4">
      <div className="max-w-[1200px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-[56px] font-normal tracking-[-0.04em] leading-[1.2] text-foreground mb-5">
            Questions? Answers.
          </h2>
          <p className="text-muted-foreground text-base md:text-[19px] leading-[1.7] max-w-2xl mx-auto">
            Everything you need to know about our design subscription service.
          </p>
        </motion.div>

        <div className="max-w-[800px] mx-auto space-y-3">
          {faqs.map((faq, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              className="bg-secondary border border-border rounded-[15px] overflow-hidden cursor-pointer"
              style={{ boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.1)" }}
              onClick={() => setOpen(open === i ? null : i)}
            >
              <div className="flex items-center justify-between p-5 md:p-6">
                <h5 className="text-foreground text-base md:text-[19px] font-medium leading-[1.4] pr-4">
                  {faq.question}
                </h5>
                <motion.div
                  animate={{ rotate: open === i ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                  className="flex-shrink-0"
                >
                  <ChevronDown className="w-5 h-5 text-muted-foreground" />
                </motion.div>
              </div>
              <AnimatePresence>
                {open === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="px-5 md:px-6 pb-5 md:pb-6">
                      <p className="text-muted-foreground text-sm md:text-base leading-[1.8]">{faq.answer}</p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
