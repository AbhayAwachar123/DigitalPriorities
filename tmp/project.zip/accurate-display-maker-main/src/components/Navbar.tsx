import { motion } from "framer-motion";
import designfastLogo from "@/assets/designfast-logo.png";
import { useState } from "react";
import { Menu, X } from "lucide-react";

const Navbar = () => {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <motion.nav
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, type: "spring", bounce: 0.2 }}
      className="fixed top-4 md:top-[30px] left-1/2 -translate-x-1/2 z-50 w-[90%] max-w-[1200px]"
    >
      <div
        className="flex items-center justify-between backdrop-blur-[20px] bg-secondary border border-[rgba(255,255,255,0.07)] rounded-[20px] px-5 md:px-[30px] py-[15px]"
        style={{ boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.25)" }}
      >
        <a href="/" className="block w-[118px] md:w-[151px]">
          <img src={designfastLogo} alt="Designfast Logo" className="w-full h-auto" />
        </a>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-10">
          <a href="#" className="text-foreground text-base font-medium hover:text-muted-foreground transition-colors">Home</a>
          <a href="#" className="text-foreground text-base font-medium hover:text-muted-foreground transition-colors">Services</a>
          <a href="#" className="text-foreground text-base font-medium hover:text-muted-foreground transition-colors">About Us</a>
          <a href="#" className="text-foreground text-base font-medium hover:text-muted-foreground transition-colors">Case Studies</a>
        </div>

        {/* Contact Button - Desktop */}
        <a
          href="#"
          className="hidden md:block bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-[15px] rounded-[10px] text-base font-medium transition-colors relative overflow-hidden group"
          style={{ boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.25)" }}
        >
          <span className="absolute inset-0 bg-foreground opacity-0 group-hover:opacity-10 blur-[40px] transition-opacity" />
          <span className="relative">Contact us</span>
        </a>

        {/* Mobile hamburger */}
        <button className="md:hidden text-foreground" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Nav */}
      {mobileOpen && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden mt-2 bg-secondary border border-border rounded-[20px] p-8 flex flex-col gap-6"
          style={{ boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.25)" }}
        >
          <a href="#" className="text-foreground text-lg font-medium" onClick={() => setMobileOpen(false)}>Home</a>
          <a href="#" className="text-foreground text-lg font-medium" onClick={() => setMobileOpen(false)}>Services</a>
          <a href="#" className="text-foreground text-lg font-medium" onClick={() => setMobileOpen(false)}>About Us</a>
          <a href="#" className="text-foreground text-lg font-medium" onClick={() => setMobileOpen(false)}>Case Studies</a>
          <a
            href="#"
            className="bg-primary text-primary-foreground px-6 py-4 rounded-[10px] text-center font-medium"
            style={{ boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.25)" }}
          >
            Contact us
          </a>
        </motion.div>
      )}
    </motion.nav>
  );
};

export default Navbar;
