import { motion } from "framer-motion";
import { Check } from "lucide-react";

const plans = [
  {
    title: "Landing Page",
    description: "A high-converting landing page designed to drive results.",
    price: "$2,497",
    unit: "/page",
    features: ["Unlimited requests", "Figma file", "Mobile responsive", "48-hour delivery"],
    accent: false,
  },
  {
    title: "Dedicated Team",
    description: "Your own scalable design team on a monthly subscription.",
    price: "$4,497",
    unit: "/month",
    features: ["Unlimited requests", "Figma file", "Slack access", "Ongoing revisions"],
    accent: true,
  },
];

const PricingSection = () => {
  return (
    <section className="py-20 px-4">
      <div className="max-w-[1200px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-[56px] font-normal tracking-[-0.04em] leading-[1.2] text-foreground mb-5">
            Pricing
          </h2>
          <p className="text-muted-foreground text-base md:text-[19px] leading-[1.7] max-w-2xl mx-auto">
            Simple, transparent pricing that scales with your needs.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 max-w-[900px] mx-auto">
          {plans.map((plan, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="relative bg-secondary border border-border rounded-[20px] p-8 flex flex-col overflow-hidden"
              style={{ boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.25)" }}
            >
              {plan.accent && (
                <div
                  className="absolute inset-0"
                  style={{
                    backgroundColor: "hsl(var(--primary))",
                    maskImage: "linear-gradient(0deg, rgba(0,0,0,0) 0%, rgba(0,0,0,0.1) 100%)",
                    WebkitMaskImage: "linear-gradient(0deg, rgba(0,0,0,0) 0%, rgba(0,0,0,0.1) 100%)",
                  }}
                />
              )}

              <div className="relative z-10">
                <div className="mb-6">
                  <h4 className="text-foreground text-xl font-medium mb-2">{plan.title}</h4>
                  <p className="text-muted-foreground text-sm leading-[1.8]">{plan.description}</p>
                </div>

                <div className="flex items-baseline gap-1 mb-8">
                  <span className="text-foreground text-4xl font-normal tracking-[-0.04em]">{plan.price}</span>
                  <span className="text-[hsl(var(--muted-foreground))] text-sm" style={{ color: "rgb(84, 84, 84)" }}>{plan.unit}</span>
                </div>

                <div className="space-y-3 mb-8">
                  {plan.features.map((f, j) => (
                    <div key={j} className="flex items-center gap-3">
                      <Check className="w-4 h-4 text-primary flex-shrink-0" />
                      <span className="text-muted-foreground text-sm">{f}</span>
                    </div>
                  ))}
                </div>

                <a
                  href="#"
                  className={`block text-center py-4 px-6 rounded-[10px] text-sm font-medium transition-colors ${
                    plan.accent
                      ? "bg-primary text-primary-foreground hover:bg-primary/90"
                      : "bg-accent text-foreground hover:bg-accent/80"
                  }`}
                  style={plan.accent ? { boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.25)" } : {}}
                >
                  Request a quote
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
