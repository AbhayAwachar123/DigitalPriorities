import designfastLogo from "@/assets/designfast-logo.png";
import { Twitter, Instagram, Linkedin } from "lucide-react";

const FooterSection = () => {
  return (
    <footer className="py-20 px-4 border-t border-border">
      <div className="max-w-[1200px] mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-10">
          {/* Logo + Description */}
          <div className="md:col-span-2 space-y-3">
            <a href="/" className="block w-[174px]">
              <img src={designfastLogo} alt="Designfast Logo" className="w-full h-auto" />
            </a>
            <p className="text-muted-foreground text-sm leading-[1.8] max-w-[300px]">
              Your on-demand design team. Beautiful, conversion-focused websites delivered fast.
            </p>
          </div>

          {/* Pages */}
          <div className="space-y-5">
            <h5 className="text-foreground text-[19px] font-medium">Pages</h5>
            <div className="space-y-2">
              {["Home", "Services", "About Us", "Case Studies", "Contact"].map((link) => (
                <a key={link} href="#" className="block text-muted-foreground text-sm hover:text-foreground transition-colors">
                  {link}
                </a>
              ))}
            </div>
          </div>

          {/* Legal */}
          <div className="space-y-5">
            <h5 className="text-foreground text-[19px] font-medium">Legal</h5>
            <div className="space-y-2">
              {["Privacy Policy", "Cookie Policy", "Terms of Service"].map((link) => (
                <a key={link} href="#" className="block text-muted-foreground text-sm hover:text-foreground transition-colors">
                  {link}
                </a>
              ))}
            </div>
          </div>

          {/* Social Icons */}
          <div className="flex md:flex-col md:items-end gap-2">
            {[
              { Icon: Twitter, href: "https://x.com" },
              { Icon: Instagram, href: "https://instagram.com" },
              { Icon: Linkedin, href: "https://linkedin.com" },
            ].map(({ Icon, href }, i) => (
              <a
                key={i}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-[5px] bg-secondary border border-[rgba(255,255,255,0.1)] flex items-center justify-center hover:bg-accent transition-colors"
                style={{ boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.25)" }}
              >
                <Icon className="w-4 h-4 text-foreground" />
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default FooterSection;
