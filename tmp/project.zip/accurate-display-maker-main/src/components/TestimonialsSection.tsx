import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import testimonialSarah from "@/assets/testimonial-sarah.jpg";
import testimonialDavid from "@/assets/testimonial-david.jpg";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";

const testimonials = [
  {
    quote: "The subscription model is genius. We get unlimited design requests and the quality is always exceptional. It's like having an in-house design team without the overhead.",
    name: "Jason Bates",
    role: "Startup Founder",
    image: testimonialDavid,
  },
  {
    quote: "Since switching to their service, our conversion rates have skyrocketed. The designs are clean, modern, and optimized for results.",
    name: "Jake Thompson",
    role: "SaaS CEO",
    image: testimonialSarah,
  },
  {
    quote: "A game changer! We get professional-quality design work on demand. The designs are great and always delivered faster than we expect.",
    name: "Sarah Lin",
    role: "Marketing Director",
    image: testimonialSarah,
  },
  {
    quote: "They've made scaling design output effortless for our agency. Their designers are responsive, quick to iterate, and always nail the brief.",
    name: "David Miller",
    role: "Agency Owner",
    image: testimonialDavid,
  },
];

const TestimonialsSection = () => {
  const [current, setCurrent] = useState(0);

  const next = () => setCurrent((p) => (p + 1) % testimonials.length);
  const prev = () => setCurrent((p) => (p - 1 + testimonials.length) % testimonials.length);

  const t = testimonials[current];

  return (
    <section className="py-20 px-4">
      <div className="max-w-[1200px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-[56px] font-normal tracking-[-0.04em] leading-[1.2] text-foreground mb-5">
            What our clients say
          </h2>
          <p className="text-muted-foreground text-base md:text-[19px] leading-[1.7] max-w-2xl mx-auto">
            Don't take our word for it—hear from the founders, CEOs, and marketing leaders who trust us.
          </p>
        </motion.div>

        <div className="relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={current}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.4 }}
              className="bg-secondary border border-border rounded-[20px] p-8 md:p-16 text-center"
              style={{ boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.07)" }}
            >
              <Quote className="w-8 h-8 text-primary mx-auto mb-6" />
              <p className="text-foreground text-xl md:text-2xl font-normal leading-[1.5] mb-10 max-w-3xl mx-auto">
                {t.quote}
              </p>
              <div className="flex items-center justify-center gap-3">
                <div className="w-12 h-12 rounded-full overflow-hidden">
                  <img src={t.image} alt={t.name} className="w-full h-full object-cover" />
                </div>
                <div className="text-left">
                  <p className="text-foreground text-sm font-medium">{t.name}</p>
                  <p className="text-muted-foreground text-xs">{t.role}</p>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation */}
          <div className="absolute inset-y-0 left-0 right-0 flex items-center justify-between pointer-events-none">
            <button
              onClick={prev}
              className="w-10 h-10 rounded-[5px] bg-[rgba(255,255,255,0.03)] flex items-center justify-center pointer-events-auto -ml-5 hover:bg-[rgba(255,255,255,0.08)] transition-colors"
            >
              <ChevronLeft className="w-5 h-5 text-foreground" />
            </button>
            <button
              onClick={next}
              className="w-10 h-10 rounded-[5px] bg-[rgba(255,255,255,0.03)] flex items-center justify-center pointer-events-auto -mr-5 hover:bg-[rgba(255,255,255,0.08)] transition-colors"
            >
              <ChevronRight className="w-5 h-5 text-foreground" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
