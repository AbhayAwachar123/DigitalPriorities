import { motion } from "framer-motion";
import { FileX, Target, Zap, Paintbrush } from "lucide-react";

const items = [
  { icon: FileX, title: "No contracts", description: "Pause or cancel anytime—flexibility for your business." },
  { icon: Target, title: "Conversion focused", description: "We design with one goal: turning visitors into buyers." },
  { icon: Zap, title: "Fast delivery", description: "Most requests are completed in 48 hours or less." },
  { icon: Paintbrush, title: "Top quality", description: "Premium design work from experienced professionals." },
];

const WhyChooseUsSection = () => {
  return (
    <section className="py-20 px-4">
      <div className="max-w-[1200px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-[56px] font-normal tracking-[-0.04em] leading-[1.2] text-foreground mb-5">
            Why choose us?
          </h2>
          <p className="text-muted-foreground text-base md:text-[19px] leading-[1.7] max-w-2xl mx-auto">
            We make web design simple, fast, and scalable with a subscription model that puts you in control.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="flex flex-col md:flex-row items-center justify-center gap-8 md:gap-0"
        >
          {items.map((item, i) => (
            <div key={i} className="flex items-center">
              <div className="flex flex-col items-center text-center px-6 md:px-8">
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center mb-4 border border-[rgba(255,255,255,0.15)]"
                  style={{
                    background: "linear-gradient(180deg, hsl(var(--secondary)) 0%, hsl(var(--background)) 100%)",
                    boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.25)",
                  }}
                >
                  <item.icon className="w-6 h-6 text-foreground" />
                </div>
                <h4 className="text-foreground text-lg font-medium mb-2">{item.title}</h4>
                <p className="text-muted-foreground text-sm leading-[1.8] max-w-[200px]">{item.description}</p>
              </div>
              {i < items.length - 1 && (
                <div className="hidden md:block w-px h-24 bg-border" />
              )}
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default WhyChooseUsSection;
