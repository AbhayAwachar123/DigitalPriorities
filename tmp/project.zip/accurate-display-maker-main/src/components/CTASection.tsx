import { motion } from "framer-motion";
import gridPattern from "@/assets/grid-pattern.png";

const CTASection = () => {
  return (
    <section className="py-20 px-4">
      <div className="max-w-[1200px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="relative bg-secondary border border-[rgba(255,255,255,0.1)] rounded-[20px] p-10 md:p-20 text-center overflow-hidden"
          style={{ boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.25)" }}
        >
          {/* Grid background with perspective */}
          <div className="absolute inset-0 flex items-center justify-center opacity-80">
            <div
              className="w-full h-full"
              style={{
                backgroundImage: `url(${gridPattern})`,
                backgroundRepeat: "repeat",
                backgroundPosition: "center top",
                backgroundSize: "1200px auto",
                transform: "perspective(1200px) rotateX(70deg)",
                maskImage: "radial-gradient(50% 50% at 50% 50%, rgba(0,0,0,1) 79%, rgba(0,0,0,0) 100%)",
                WebkitMaskImage: "radial-gradient(50% 50% at 50% 50%, rgba(0,0,0,1) 79%, rgba(0,0,0,0) 100%)",
              }}
            />
            {/* Blur overlay */}
            <div
              className="absolute w-[300px] h-[300px] rounded-full"
              style={{
                backgroundColor: "rgba(255, 255, 255, 0.5)",
                filter: "blur(100px)",
                maskImage: "radial-gradient(50% 50% at 50% 50%, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0) 100%)",
                WebkitMaskImage: "radial-gradient(50% 50% at 50% 50%, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0) 100%)",
              }}
            />
          </div>

          <div className="relative z-10">
            {/* Badge */}
            <div
              className="inline-flex items-center gap-2 bg-secondary border border-[rgba(255,255,255,0.05)] rounded-full px-5 py-2 mb-8"
              style={{ boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.25)" }}
            >
              <span className="w-2 h-2 bg-green-dot rounded-[8px]" />
              <span className="text-muted-foreground text-sm">3 spots left for Q2</span>
            </div>

            <h2
              className="text-3xl md:text-[56px] font-normal tracking-[-0.04em] leading-[1.2] text-foreground mb-5"
              style={{
                maskImage: "linear-gradient(0deg, rgba(0,0,0,0.5) 0%, rgba(0,0,0,1) 100%)",
                WebkitMaskImage: "linear-gradient(0deg, rgba(0,0,0,0.5) 0%, rgba(0,0,0,1) 100%)",
              }}
            >
              Let's work together
            </h2>

            <p className="text-muted-foreground text-base md:text-[19px] leading-[1.7] max-w-2xl mx-auto mb-10">
              Join our subscription service and get your dream website designed and launched by experts. Start today, scale tomorrow!
            </p>

            <a
              href="#"
              className="inline-block bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 rounded-[10px] text-base font-medium transition-colors relative overflow-hidden group"
              style={{ boxShadow: "inset 0px 1px 20px 0px rgba(255, 255, 255, 0.25)" }}
            >
              <span className="absolute inset-0 bg-foreground opacity-0 group-hover:opacity-10 blur-[40px] transition-opacity" />
              <span className="relative">Book a call</span>
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CTASection;
